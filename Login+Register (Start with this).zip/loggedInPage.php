<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Header of Website</title></head>
<link rel="stylesheet" type="text/css" href="style.css">
<body>
<?php include('header.html');?>
<p>it works, here we are going to create the movie managment system.
   It will generate something different based on user login credentials.
   </p>
<?php include('footer.html');?>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<body>
